const { calculateMultiply } = require("./multiply");

const { calculateSum } = require("./sum");

module.exports = { calculateMultiply, calculateSum };
